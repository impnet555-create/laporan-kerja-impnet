const CACHE_NAME = 'imp-hotspot-v3';

/* ===== INSTALL ===== */
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            return cache.addAll([
                './',
                './index.html',
                './teknisi.html',
                './login.html',
                './manifest.json'
            ]);
        })
    );
    self.skipWaiting();
});

/* ===== ACTIVATE ===== */
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys =>
            Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
        )
    );
    self.clients.claim();
});

/* ===== FETCH (CACHE) ===== */
self.addEventListener('fetch', event => {
    if (event.request.url.includes('firebaseio.com')) return;
    if (event.request.method !== 'GET') return;

    event.respondWith(
        fetch(event.request)
            .then(response => {
                if (response && response.status === 200) {
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
                }
                return response;
            })
            .catch(() => caches.match(event.request))
    );
});

/* ===== NOTIFIKASI: Terima push dari halaman ===== */
self.addEventListener('message', event => {
    if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
        const data = event.data.payload;
        self.registration.showNotification(data.title, {
            body: data.body,
            icon: './icons/icon-192.png',
            badge: './icons/icon-72.png',
            vibrate: [200, 100, 200],
            tag: data.tag || 'imp-notif-' + Date.now(),
            renotify: true,
            data: {
                url: data.url || './teknisi.html',
                idLaporan: data.idLaporan || '',
                tipe: data.tipe || ''
            }
        });
    }
});

/* ===== NOTIFIKASI: User klik notifikasi ===== */
self.addEventListener('notificationclick', event => {
    event.notification.close();

    const data = event.notification.data || {};
    let url = data.url || './teknisi.html';

    // Jika ada ID laporan, arahkan ke detail
    if (data.idLaporan) {
        url = './teknisi.html?open=' + data.idLaporan;
    }

    event.waitUntil(
        self.clients.matchAll({ type: 'window', includeUncontrolled: true })
            .then(clients => {
                // Cek apakah app sudah terbuka
                for (let i = 0; i < clients.length; i++) {
                    const client = clients[i];
                    if (client.url.includes('teknisi.html') && 'focus' in client) {
                        client.navigate(url);
                        return client.focus();
                    }
                }
                // Jika belum terbuka, buka baru
                return self.clients.openWindow(url);
            })
    );
});